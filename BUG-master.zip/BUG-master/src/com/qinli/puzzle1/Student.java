package com.qinli.puzzle1;

/**
 * @Author Cambria
 * @creat 2021/2/3 23:31
 */
public class Student {
    String name;
    int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }


}
